import { Component, OnInit, Input ,Output,EventEmitter } from '@angular/core'
import { Profesor } from 'src/app/clases/profesor';

@Component({
// tslint:disable-next-line: component-selector
  selector: '[app-fila-profesor]',
  templateUrl: './fila-profesor.component.html',
  styleUrls: ['./fila-profesor.component.css']
})
export class FilaProfesorComponent implements OnInit {
  @Output() profesorSeleccionado: EventEmitter<any>= new EventEmitter<any>();
  @Input()  unProfesor: Profesor[];

  constructor() { }

  ngOnInit() {

  }

  mostrarDetalles(parametroProfesor)
  {
    this.profesorSeleccionado.emit(parametroProfesor);
  }
}
