import { Component, OnInit, Input } from '@angular/core';//debe tener un input
import { Usuario } from 'src/app/clase/usuario';

@Component({
  selector: 'app-component-input',
  templateUrl: './component-input.component.html',
  styleUrls: ['./component-input.component.css']
})
export class ComponentInputComponent implements OnInit {

  //@Input() dato: string;// dato que nos envian desde el html

  @Input() datoInput: Usuario;

  constructor() {
   }

  ngOnInit() {
  }

}
