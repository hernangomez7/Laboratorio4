import { Component, OnInit } from '@angular/core';
import { Usuario } from 'src/app/clase/usuario';
import {Router} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public unUsuario: Usuario;

  constructor(private router: Router) {
    this.unUsuario = new Usuario( 'name', 'pass');
  }

  navergar(){
    this.router.navigate(['/Error', {id: 7}]);
  }

  ngOnInit() {
  }

}

