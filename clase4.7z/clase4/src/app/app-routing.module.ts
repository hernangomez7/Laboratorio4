import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InicioComponent } from '../app/componentes/inicio/inicio.component';
import { DescripcionComponent } from './componentes/descripcion/descripcion.component';

const routes: Routes = [
  { path: 'inicio', component: InicioComponent,
   children:
    [
     { path: 'componente1', component: DescripcionComponent }
    ]
 },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
