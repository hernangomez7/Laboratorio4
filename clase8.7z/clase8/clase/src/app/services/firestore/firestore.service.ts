import { Injectable } from '@angular/core';
import { AngularFirestore, AngularFirestoreDocument } from 'angularfire2/firestore';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FirestoreService {

  constructor(
    private firestore: AngularFirestore
  ) {}
  //Crea un nuevo mensaje
  public createMessage(data: {nombre: string, url: string})
  {
    return this.firestore.collection('message').add(data);
  }

  //Obtiene un mensaje
  public getMessage(documentId: string)
  {
    return this.firestore.collection('message').doc(documentId).snapshotChanges();
  }
  //Obtiene todos los mensajes
  public getMessages()
  {
    return this.firestore.collection('message').snapshotChanges();
  }
  //Actualiza un mensaje
  public updateMessage(documentId: string, data: any)
  {
    return this.firestore.collection('message').doc(documentId).set(data);
  }
}
