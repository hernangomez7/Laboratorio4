export class Usuario {

  public nombre:string;
  public clave:string;

  constructor (nombreIng:string,claveIng:string)
  {
    this.nombre = nombreIng;
    this.clave = claveIng;
  }


}

