import { Component, OnInit } from '@angular/core';
import { Usuario } from 'src/app/clase/usuario';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public unUsuario:Usuario;

  constructor() {
    this.unUsuario = new Usuario("name","pass");
  }

  ngOnInit() {
  }

}
