import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { AuthService, message } from  '../../servicios/auth.service';
import { GestorDatosService } from  '../../servicios/gestor-datos.service';

// import { Usuario } from '../../clases/usuario';

@Component({
  selector: 'app-cabecera',
  templateUrl: './cabecera.component.html',
  styleUrls: ['./cabecera.component.css']
})
export class CabeceraComponent implements OnInit
{
  public mailUsuarioActual:string = "";
  public tipoUsuarioActual:string = "";

  public ocultarPaciente:boolean = true;

  @Output() funcion = new EventEmitter<string>();
  
  constructor(private authService:AuthService, private gestorDatosService:GestorDatosService)
  {
    this.IniciarCabecera();

    if(this.tipoUsuarioActual == "paciente") this.ocultarPaciente = false; 
    else this.ocultarPaciente = true; 
  }

  ngOnInit(){
  }

  IniciarCabecera()
  {
     var myLocalUser = JSON.parse(localStorage.getItem("user") );

    this.gestorDatosService.TraerTipoUsuario().subscribe(usuariosArray =>{
      usuariosArray.forEach(element => {
        //console.log( element.mail );
        if(element.uid == myLocalUser.uid)
        {
          this.tipoUsuarioActual = element.tipo_usuario;
          this.mailUsuarioActual = element.mail;

        }
      });

    })

  }

  BotonPedirTurno()
  {
    this.funcion.emit("pedirTurno");
  }

  BotonListarMascota()
  {
    this.funcion.emit("listarMascota");
  }

  BotonListarTurno()
  {
    this.funcion.emit("listarTurno");
  }

  BotonAgregarMascota()
  {
    this.funcion.emit("agregarMascota");
  }

}
