import { Component, OnInit, Input } from '@angular/core';

import { GestorDatosService } from  '../../servicios/gestor-datos.service';

import { Mascota } from '../../clases/mascota';

@Component({
  selector: 'app-alta-mascota',
  templateUrl: './alta-mascota.component.html',
  styleUrls: ['./alta-mascota.component.css']
})
export class AltaMascotaComponent implements OnInit
{
  public mascotaNueva:Mascota = new Mascota();

  constructor(private gestorService:GestorDatosService) { }

  ngOnInit() {
  }

  EnviarMascotaMascota()
  {
    var myLocalUser = JSON.parse(localStorage.getItem("user") );
    //serv.enviar(mascotaNueva)
    this.mascotaNueva.dueño = myLocalUser.email;

    // console.log(this.mascotaNueva);

    this.gestorService.GuardarMascota(this.mascotaNueva,myLocalUser.uid);

    this.mascotaNueva = new Mascota();
  }

  VerificarGuardar()
  {
    this.EnviarMascotaMascota();
  }

  AutoFull()
  {
    this.mascotaNueva.nombre = "ruffo";
    this.mascotaNueva.edad = 1;
    this.mascotaNueva.animal = "perro";
    this.mascotaNueva.raza = "carnicero";

  }

}
