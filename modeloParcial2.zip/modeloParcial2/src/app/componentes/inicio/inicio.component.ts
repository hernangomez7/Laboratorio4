import { Component, OnInit } from '@angular/core';
//1º agregamos un cierre de cesion
import { AuthService, message } from  '../../servicios/auth.service';





@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.component.html',
  styleUrls: ['./inicio.component.css']
})
export class InicioComponent implements OnInit
{

  public usuariosArray:any = [];
  public mailUsuarioActual:string = "";

  constructor(private  authService:  AuthService) { }

  ngOnInit() {
  }

  traerUser()
  {
    this.authService.getUsers().subscribe(users =>{
      this.usuariosArray = users;
      console.log(users);
    })
  
  }

  //esta funcion utiliza usuariosArray que esta vacia hasta utilizar traerUser(); q traera usuarios
  //siendo que el nombre debe salir de la base de datos asociando el uid de usuario con el BD.usuarios.uid
  GuardarMensaje()
  {
    const mensaje: message ={
          content : "mensaje de prueba 2",
          type : 'text',
          date : new Date(),
          propietario: this.usuariosArray[0].name
        }
     // this.authService.EnviarMsj( mensaje,this.usuariosArray[0].uid);
     this.authService.EnviarMsj( mensaje,"rqLWCRUiMayTZUiFT0fk");
      //this.msg = "";
   }

  BorrarMensajes()
  {
    this.authService.ReiniciarEnviarMsj("rqLWCRUiMayTZUiFT0fk");
  }

   

   MostrarUsuarioActual()
  {
    //var myLocalUser = JSON.stringify(localStorage.getItem("user") );

    var myLocalUser = JSON.parse(localStorage.getItem("user") );
    
    console.log("uid:"+ myLocalUser.uid );
    console.log("mail:"+ myLocalUser.email );

  }

  Nexo(funcion:string)
  {
    switch(funcion)
    {
      case "pedirTurno":
        console.log("pidio Turno!");
      break;

      case "listarMascota":
        console.log("listo Mascota!");
      break;

      case "listarTurno":
      console.log("listo Turno!");
      break;

      case "agregarMascota":
      console.log("agrego Mascota!");
      break;

      default:
        console.log("no hacer nada");
      break;

    }
  }

  AsignarDueño(dueño:string)
  {
    this.mailUsuarioActual = dueño;
  }

}
