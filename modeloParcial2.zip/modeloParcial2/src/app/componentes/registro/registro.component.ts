import { Component, OnInit } from '@angular/core';

import { AuthService } from '../../servicios/auth.service';
import { Router }  from '@angular/router';
//reCaptcha
import { FormControl } from '@angular/forms';

import { Usuario } from '../../clases/usuario';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.component.html',
  styleUrls: ['./registro.component.css']
})
export class RegistroComponent implements OnInit {

  // myRecaptcha = new FormControl(true);
  // myRecaptcha: boolean;
  public captchaVerificado:boolean = false;

  ocultarForm:boolean = true;

  public ocultarClaveAdmin:boolean = true;
  public usuarioEnviar:Usuario = new Usuario();
  public claveAdmin:string = "";


  constructor(private auth:AuthService, private router:Router) { }

  ngOnInit()
  {}

 Registrar()
 {
   if(this.captchaVerificado == true)
    {
      this.auth.registrarDatos(this.usuarioEnviar).then(auth => {
        this.router.navigate(['/login']);
        // console.log(auth);
      }).catch(err => console.log(err));
    }else{
      alert('Resuelva el captcha o muera en el intento');
    }
  }


  captchaResuelto(respuestaCaptcha: string)
  {
    //console.log(`Resolved captcha with response: ${respuestaCaptcha}`);
    if(respuestaCaptcha != null)
    {
      this.captchaVerificado = true;
    }
  }


  AsignarTipo_usuario(asignacion:string)
  {
    this.usuarioEnviar.tipo_usuario = asignacion;
    if(asignacion == "administrador")this.ocultarClaveAdmin = false;
    else this.ocultarClaveAdmin = true;
  }

  VerificarRegistrar()
  {
    var validado:boolean = true;

    if(!this.ValidarMail(this.usuarioEnviar.mail))
    {
      validado = false;
      console.log("No es un correo electronico valido");
    }

    if(this.usuarioEnviar.clave.length < 6)
    {
      validado = false;
      console.log("la clave debe tener un minimo de 6 caracteres");
    }

    if(this.usuarioEnviar.tipo_usuario == "administrador")
    {
      if(this.claveAdmin != "admin")
      {
        validado = false;
        console.log("la clave de  administrador es incorrecta");
      }
    }

    if(validado)this.Registrar();
  }

  ValidarNombre(nombre:string)
  {
    var expRegNombre=/^[a-zA-ZÑñÁáÉéÍíÓóÚúÜü\s]+$/;
    if(expRegNombre.exec(nombre)) return true
    else return false;
  }

  ValidarMail(mail:string):boolean
  {
    var expRegCorreo=/^\w+@(\w+\.)+\w{2,4}$/; 
    if(expRegCorreo.exec(mail)) return true
    else return false;
  }

  ValidarApellido(nombre:string)
  {
    var expRegApellidos=/^[a-zA-ZÑñÁáÉéÍíÓóÚúÜü\s]+$/;
    if(expRegApellidos.exec(nombre)) return true
    else return false;
  }



}
