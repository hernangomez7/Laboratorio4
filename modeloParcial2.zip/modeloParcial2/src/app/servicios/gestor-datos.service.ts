import { Injectable } from '@angular/core';

import { AngularFirestore }  from '@angular/fire/firestore';
import { firestore } from 'firebase';

import { map } from 'rxjs/operators';

import { Usuario } from '../clases/usuario';
import { Mascota } from '../clases/mascota';



@Injectable({
  providedIn: 'root'
})
export class GestorDatosService {

  constructor( private db:AngularFirestore ) { }

  TraerTipoUsuario()
  {
    return this.db.collection('users').snapshotChanges().pipe(map(usuarios=>{
      return usuarios.map(a=>{
        const data = a.payload.doc.data() as Usuario;
        data.uid = a.payload.doc.id;

        return data;
      })
    }))
  }

  

  GuardarMascota(mascotaNuevo:Mascota, uidDueño:string)
  {
    console.log(uidDueño);
    console.log(mascotaNuevo);

    this.db.collection("pets").doc(uidDueño).update({
        //NOTA:no guardara datos que sean iguales por completo
        //NOTA2:no puede guardar tipo:Mascota debido a que guarda datos solo javaScript tendria que guardar
        //{dato:string,otroDato:string,...} que seria nativo de JSt al usar Object.assign funca.
        messages :  firestore.FieldValue.arrayUnion( (Object.assign({}, mascotaNuevo)) )
      })
  }

//messages :  firestore.FieldValue.arrayUnion( (Object.assign({}, mascotaNuevo)) )

}
