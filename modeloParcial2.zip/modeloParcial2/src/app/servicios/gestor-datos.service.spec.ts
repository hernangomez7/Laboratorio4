import { TestBed } from '@angular/core/testing';

import { GestorDatosService } from './gestor-datos.service';

describe('GestorDatosService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: GestorDatosService = TestBed.get(GestorDatosService);
    expect(service).toBeTruthy();
  });
});
