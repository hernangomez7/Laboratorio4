import { Injectable } from  '@angular/core';
//1º add
import { Router } from  "@angular/router";
import { auth } from  'firebase/app';
import { AngularFireAuth } from  "@angular/fire/auth";
import { User } from  'firebase';
//para agregar datos en db
import { AngularFirestore }  from '@angular/fire/firestore';
import { map } from 'rxjs/operators';
import { firestore } from 'firebase';

import { Usuario } from '../clases/usuario';
import { Mascota } from '../clases/mascota';


export interface message
{
  content:string;
  type:string;
  date:Date;
  propietario:string;
}



@Injectable({
    providedIn:  'root'
})
export  class  AuthService
{
  //1ºdatos de usuario a guardar
  user:  User;
  //2ºinjectamos
  constructor(public  afAuth:AngularFireAuth, public  router:  Router, private db:AngularFirestore)
  {
    //3ºnos subcribimos a auth si el usuario ha iniciado sesión, agregamos los datos del usuario al almacenamiento
    //local del navegador; de lo contrario almacenamos un usuario nulo.
    this.afAuth.authState.subscribe(user => {
      if (user) {
        this.user = user;
        localStorage.setItem('user', JSON.stringify(this.user));
      } else {
        localStorage.setItem('user', null);
      }
    })
  }
 
  async  login(email:  string, password:  string)
  {
    try
    {
        await this.afAuth.auth.signInWithEmailAndPassword(email, password);
        this.router.navigate(['inicio']);//sin logearse se dirige aqui
    } catch (e)
    {
        alert("Error!"  +  e.message);
    }
  }

  async logout()
  {
    await this.afAuth.auth.signOut();
    localStorage.removeItem('user');
    this.router.navigate(['login']);
  }
  //6º verificara si esta logeado
  get isLoggedIn(): boolean
  {
    const  user  =  JSON.parse(localStorage.getItem('user'));
    return  user  !==  null;
  }

  registrarDatos(usuario:Usuario)
  {
    return new Promise ((resolve, reject) => {
      this.afAuth.auth.createUserWithEmailAndPassword(usuario.mail,usuario.clave).then(res => {
        const uid = res.user.uid;
        //guarda datos de usuario
        this.db.collection('users').doc(res.user.uid).set({
          mail: usuario.mail,
          uid : uid,
          tipo_usuario : usuario.tipo_usuario
        })
        //crea almacen de mascotas con mismo uid
        var arrayNuevo:Array<Mascota> = new Array();
        this.db.collection("pets").doc(res.user.uid).set({
          
        })

        resolve(res)
      }).catch( err =>   reject(alert("Error! "  +  err.message) ))//reject(err))
    })
    
  }


  //trae usuarios
  getUsers()
  {
    return this.db.collection('users').snapshotChanges().pipe(map(usuarios=>{
      return usuarios.map(a=>{
        const data = a.payload.doc.data() as Usuario;
        data.uid = a.payload.doc.id;

        return data;
      })
    }))
  }


  //guarda mensaje dentro de las variables de MENSAJES en la db de FB
  EnviarMsj(message:message,chat_id:string)
  {
    //dentro de coleccion "mensajes" en la fila "xxx" update o actualizar a ( (coleccion)messages con "message" + nuevo "message" )
    this.db.collection("mensajes").doc(chat_id).update({
      //este messages es el de firebase
      messages :  firestore.FieldValue.arrayUnion(message),
    })
  }

  ReiniciarEnviarMsj(chat_id:string)
  {
    //dentro de coleccion "mensajes" en la fila "xxx" update o actualizar a ( (coleccion)messages = "" )
    this.db.collection("mensajes").doc(chat_id).update({
      messages : ""
    })
  }



  //trae lo de adentro de el contenido de un item de la coleccion
  /*
  getChatRooms()
  {
    return this.db.collection('chatsRoom').snapshotChanges().pipe(map(rooms=>{
      return rooms.map(a=>{
        const data = a.payload.doc.data() as chat;
        data.id = a.payload.doc.id;
        return data;
      })
    }))
  }
  //trae un item de la coleccion
  getChatRoom(chat_id:string)
  {
    return this.db.collection("chatsRoom").doc(chat_id).valueChanges();
  }
  //envia un message, al item que tenga el chat_id en chatsRoom
  sendMsgToFirebase(message:message,chat_id:string){
    this.db.collection("chatsRoom").doc(chat_id).update({
      //este messages es el de firebase
      messages :  firestore.FieldValue.arrayUnion(message),
    })
  }
  */
  

}