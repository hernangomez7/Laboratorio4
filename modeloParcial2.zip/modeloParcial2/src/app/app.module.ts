//NO OLVIDES
//npm install angularfire2 firebase --save
//npm install ng-recaptcha --save

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';



import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './componentes/login/login.component';
import { RegistroComponent } from './componentes/registro/registro.component';

import { AngularFireModule } from '@angular/fire';
import { AngularFireAuthModule } from '@angular/fire/auth';
import { AngularFirestoreModule, FirestoreSettingsToken } from '@angular/fire/firestore';
//import { ChatComponent } from './componentes/chat/chat.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { InicioComponent } from './componentes/inicio/inicio.component';
import { ErrorComponent } from './componentes/error/error.component';
import { CabeceraComponent } from './componentes/cabecera/cabecera.component';
//reCaptcha
import { RecaptchaModule } from 'ng-recaptcha';
import { AltaMascotaComponent } from './componentes/alta-mascota/alta-mascota.component';




var firebaseConfig = {
  apiKey: "AIzaSyCfsSBWspHijyGr45CSQp0RKO9ULqVqmN4",
  authDomain: "modelopacial2-v1.firebaseapp.com",
  databaseURL: "https://modelopacial2-v1.firebaseio.com",
  projectId: "modelopacial2-v1",
  storageBucket: "modelopacial2-v1.appspot.com",
  messagingSenderId: "254258549372",
  appId: "1:254258549372:web:5cc94e6413323fd6"
};

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistroComponent,
    InicioComponent,
    ErrorComponent,
    CabeceraComponent,
    AltaMascotaComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    AngularFireModule.initializeApp(firebaseConfig),
    AngularFireAuthModule,
    AngularFirestoreModule,
    RecaptchaModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

//Cs:6Lcy5KoUAAAAAOA7S9gtPCfSzbmamtSowqvQhtKs
//Cc:6Lcy5KoUAAAAAGFxmeP3QKJHUwcLH4qFNKWInQXl

