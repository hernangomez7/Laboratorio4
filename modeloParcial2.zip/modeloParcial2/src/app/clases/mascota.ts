export class Mascota
{
    public nombre:string;
    public edad:Number;//edad minima 0.1 representa una semana maximo decimal 0.11 representando 11 meses luego cuenta enteros
    public dueño:string;//si no tiene dueño se tendra que crear una cuenta con clave q sea "clave", debe poder ser modificada por el usuario
    public foto:string;//si no se elige se pone una por default
    public animal:string;//validar que sea una mascota q si atiende la veterinaria
    public raza:string;//validar que sea una raza q si atiende la veterinaria

    constructor(nombre?: string,edad?: number, dueño?: string, foto?: string, animal?:string, raza?:string) 
    {
        if(nombre) this.nombre = nombre;
        else this.nombre = "";
        if(edad) this.edad = edad;
        else this.edad = 0;
        if(dueño) this.dueño = dueño;
        else this.dueño = "";
        if(foto) this.foto = foto;
        else this.foto = "";
        if(animal) this.animal = animal;
        else this.animal = "";
        if(raza) this.raza = raza;
        else this.raza = "";
    }

}
