export class Usuario
{
    public uid:string;
    public mail:string;//
    public clave:string;//la clave puede ser publica siendo el valor clave para luego cambiarla
    public tipo_usuario:string;

    constructor(mail?: string,clave?: string,tipo_usuario?: string) 
    {
        if(mail) this.mail = mail;
        else this.mail = "";
        if(clave) this.clave = clave;
        else this.clave = "";
        if(tipo_usuario) this.tipo_usuario = tipo_usuario;
        else this.tipo_usuario = "cliente";
    }
}
