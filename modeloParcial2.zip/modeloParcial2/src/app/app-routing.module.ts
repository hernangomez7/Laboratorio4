import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';

//COMPONENTES
import { LoginComponent } from './componentes/login/login.component';
import { RegistroComponent } from './componentes/registro/registro.component';
import { InicioComponent } from './componentes/inicio/inicio.component';
import { ErrorComponent } from './componentes/error/error.component';

//MOD. rutas
import { AuthGuard } from './guards/auth.guard';
import { NoLoginGuard } from './guards/no-login.guard';

const rutas: Routes = [
  { path: '',   redirectTo: 'login', pathMatch: 'full' },
  { path:  'login',component:  LoginComponent, canActivate : [NoLoginGuard]},//no debe estar logeado
  { path:  'registro',component:  RegistroComponent, canActivate : [NoLoginGuard]},
  { path:  'inicio', component: InicioComponent, canActivate : [AuthGuard]},
  { path: '**', component: ErrorComponent}
];

/*
const appRoutes: Routes = [
  { path: '',   redirectTo: 'login', pathMatch: 'full' },
  { path:  'login',component:  LoginComponent, canActivate : [NoLoginGuard]},//no debe estar logeado
  { path:  'registro',component:  RegistroComponent, canActivate : [NoLoginGuard]},
  { path:  'inicio', component: InicioComponent, canActivate : [AuthGuard]},//debe estar logeado
  { path: '**', component: ErrorComponent}
];
*/

@NgModule({

  //RouterModule.forRoot(appRoutes, { preloadingStrategy: PreloadAllModules }),
 // imports: [RouterModule.forRoot(rutas)],
 imports: [RouterModule.forRoot(rutas , { preloadingStrategy: PreloadAllModules } )],
  exports: [RouterModule]
})
export class AppRoutingModule { }
